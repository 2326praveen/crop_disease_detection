"""
Test suite for Crop Disease Diagnosis System
"""
